package com.example.topazmobile

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Page = Color(0xFF090A10)
private val Panel = Color(0xFF151722)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9A9CAE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TopazApp() }
    }
}

@Composable
private fun TopazApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("topaz_params", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("Photo") }
    var resolution by remember { mutableStateOf(prefs.getString("resolution", "4K") ?: "4K") }
    var focus by remember { mutableStateOf(prefs.getString("focus", "Normal") ?: "Normal") }
    var grain by remember { mutableStateOf(prefs.getBoolean("grain", false)) }
    var enableParams by remember { mutableStateOf(prefs.getBoolean("enable", true)) }
    var mode by remember { mutableStateOf(prefs.getString("mode", "Dynamic") ?: "Dynamic") }
    val parameterNames = listOf(
        "Denoise", "Sharpen", "Detail Recovery", "Clarity",
        "Contrast", "Color Enhancement", "Deblur", "Brightness"
    )
    val values = remember {
        mutableStateMapOf<String, Float>().apply {
            parameterNames.forEach { put(it, prefs.getFloat(it, 0f)) }
        }
    }
    var selectedFile by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedFile = uri?.toString() ?: selectedFile
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Page, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Page, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Photo", "Video", "Library").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {},
                        label = { Text(item, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent,
                            selectedTextColor = Color.White,
                            indicatorColor = Accent.copy(alpha = .18f),
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("TOPAZAI STUDIO", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        when (tab) {
                            "Photo" -> "Photo Enhancement"
                            "Video" -> "Video Enhancement"
                            "Library" -> "Your Library"
                            else -> "AI Enhancement Studio"
                        },
                        fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White
                    )
                    Text("Professional controls · Local settings", color = Muted, fontSize = 13.sp)
                }
                if (tab == "Photo" || tab == "Video") {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(if (tab == "Photo") "Select a photo" else "Select a video", fontWeight = FontWeight.SemiBold)
                                OutlinedButton(
                                    onClick = { picker.launch(if (tab == "Photo") "image/*" else "video/*") },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(if (selectedFile.isBlank()) "Choose ${tab.lowercase()}" else "Choose another file") }
                                if (selectedFile.isNotBlank()) Text("Selected: $selectedFile", color = Muted, fontSize = 11.sp)
                                Text("AI processing requires an inference model or cloud API connection.", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Text("PRO PARAMETERS", color = Accent, fontSize = 11.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.weight(1f)) {
                                        Text("Enable parameters", fontWeight = FontWeight.SemiBold)
                                        Text("Use manual enhancement controls", color = Muted, fontSize = 12.sp)
                                    }
                                    Switch(checked = enableParams, onCheckedChange = {
                                        enableParams = it
                                        prefs.edit().putBoolean("enable", it).apply()
                                    })
                                }
                                HorizontalDivider(color = Color.White.copy(alpha = .08f))
                                Text("Resolution", fontWeight = FontWeight.SemiBold)
                                ChoiceRow(listOf("1080p", "2K", "4K"), resolution, !enableParams) {
                                    resolution = it; prefs.edit().putString("resolution", it).apply()
                                }
                                Text("Focus Repair", fontWeight = FontWeight.SemiBold)
                                ChoiceRow(listOf("Off", "Normal", "Strong"), focus, !enableParams) {
                                    focus = it; prefs.edit().putString("focus", it).apply()
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Column {
                                        Text("Grain", fontWeight = FontWeight.SemiBold)
                                        Text("Enable film grain", color = Muted, fontSize = 12.sp)
                                    }
                                    Switch(checked = grain, enabled = enableParams, onCheckedChange = {
                                        grain = it; prefs.edit().putBoolean("grain", it).apply()
                                    })
                                }
                                HorizontalDivider(color = Color.White.copy(alpha = .08f))
                                Text("Mode", fontWeight = FontWeight.SemiBold)
                                ChoiceRow(listOf("Dynamic", "Manual"), mode, !enableParams) {
                                    mode = it; prefs.edit().putString("mode", it).apply()
                                }
                                Text(
                                    if (mode == "Dynamic") "Dynamic mode: automatic parameter behavior."
                                    else "Manual mode: adjust each value from 0 to 100.",
                                    color = Muted, fontSize = 12.sp
                                )
                                if (mode == "Manual") {
                                    parameterNames.forEach { name ->
                                        val value = values[name] ?: 0f
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                Text(name, fontSize = 13.sp)
                                                Text(value.toInt().toString(), color = Accent, fontWeight = FontWeight.Bold)
                                            }
                                            Slider(
                                                value = value,
                                                onValueChange = { values[name] = it },
                                                onValueChangeFinished = { prefs.edit().putFloat(name, values[name] ?: 0f).apply() },
                                                valueRange = 0f..100f,
                                                enabled = enableParams,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = Accent,
                                                    activeTrackColor = Accent,
                                                    inactiveTrackColor = Color.White.copy(alpha = .12f)
                                                )
                                            )
                                        }
                                    }
                                } else {
                                    Text("Manual sliders appear when you select Manual mode.", color = Muted, fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = {
                                        resolution = "4K"; focus = "Off"; grain = false; enableParams = true; mode = "Dynamic"
                                        parameterNames.forEach { values[it] = 0f }
                                        prefs.edit().clear().apply()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = true
                                ) { Text("Restore defaults") }
                            }
                        }
                    }
                } else {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (tab == "Library") "No exports yet" else "Enhance photos and videos")
                                Text("Choose Photo or Video to open the professional parameter panel.", color = Muted, fontSize = 13.sp)
                            }
                        }
                    }
                }
                item {
                    Text("Settings are saved on this device. AI enhancement is not active until an AI model or cloud inference service is connected.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ChoiceRow(options: List<String>, selected: String, disabled: Boolean, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        options.forEach { option ->
            val chosen = option == selected
            FilterChip(
                selected = chosen,
                onClick = { onSelect(option) },
                enabled = !disabled,
                label = { Text(option, fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Accent.copy(alpha = .24f),
                    selectedLabelColor = Color.White,
                    labelColor = Muted
                ),
                modifier = Modifier.weight(1f)
            )
        }
    }
}
