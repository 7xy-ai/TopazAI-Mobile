package com.example.topazmobile

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.effect.Presentation
import java.io.File

class MainActivity : ComponentActivity() {
    private var language = "zh"
    private var lightMode = false
    private var page = "home"
    private var selectedVideo: Uri? = null
    private var statusView: TextView? = null
    private lateinit var root: LinearLayout

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) Toast.makeText(this, tr("已选择图片", "Photo selected", "사진 선택됨"), Toast.LENGTH_SHORT).show()
    }
    private val videoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedVideo = uri
        statusView?.text = if (uri != null) tr("已选择视频，可以开始导出。", "Video selected. Ready to export.", "동영상이 선택되었습니다. 내보낼 수 있습니다.") else ""
    }

    private val bg get() = if (lightMode) Color.rgb(246,247,251) else Color.rgb(9,10,16)
    private val panel get() = if (lightMode) Color.WHITE else Color.rgb(22,23,34)
    private val fg get() = if (lightMode) Color.rgb(24,25,38) else Color.rgb(245,245,250)
    private val muted get() = if (lightMode) Color.rgb(105,108,125) else Color.rgb(157,160,180)
    private val accent = Color.rgb(133,105,255)

    private fun tr(zh: String, en: String, ko: String): String =
        when (language) { "en" -> en; "ko" -> ko; else -> zh }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(10))
            setBackgroundColor(bg)
        }
        setContentView(root)
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        header.addView(label("TOPAZAI", 18, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        val lang = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("中文", "English", "한국어"))
            setSelection(listOf("zh","en","ko").indexOf(language))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val next = listOf("zh","en","ko")[position]
                    if (next != language) { language = next; render() }
                }
            }
        }
        header.addView(lang, LinearLayout.LayoutParams(dp(112), dp(44)))
        val theme = TextView(this).apply {
            text = if (lightMode) "☾" else "☼"
            textSize = 22f; gravity = Gravity.CENTER
            setTextColor(fg); setOnClickListener { lightMode = !lightMode; render() }
        }
        header.addView(theme, LinearLayout.LayoutParams(dp(42), dp(44)))
        root.addView(header)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        when (page) {
            "photo" -> photoPage(content)
            "video" -> videoPage(content)
            "library" -> libraryPage(content)
            else -> homePage(content)
        }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        listOf(
            "home" to tr("首页","Home","홈"),
            "photo" to tr("图片","Photo","사진"),
            "video" to tr("视频","Video","동영상"),
            "library" to tr("作品","Library","라이브러리")
        ).forEach { (key, title) ->
            val item = TextView(this).apply {
                text = title
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (page == key) accent else muted)
                setPadding(dp(5), dp(12), dp(5), dp(10))
                setOnClickListener { page = key; render() }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(nav)
    }

    private fun label(text: String, size: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(fg)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun heading(parent: LinearLayout, title: String, subtitle: String) {
        parent.addView(label(title, 27, true).apply { setPadding(0, dp(22), 0, dp(6)) })
        parent.addView(label(subtitle, 13).apply { setTextColor(muted); setPadding(0, 0, 0, dp(18)) })
    }

    private fun card(parent: LinearLayout, title: String, desc: String, action: String, click: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(panel)
            setOnClickListener { click() }
        }
        box.addView(label(title, 18, true))
        box.addView(label(desc, 13).apply { setTextColor(muted); setPadding(0, dp(7), 0, dp(15)) })
        box.addView(TextView(this).apply {
            text = action + "  →"; textSize = 13f; setTextColor(accent)
        })
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        parent.addView(box, lp)
    }

    private fun homePage(parent: LinearLayout) {
        heading(parent, tr("影像，焕然一新。","Make every frame remarkable.","모든 프레임을 새롭게."),
            tr("专业影像增强工作台","Your creative enhancement studio","전문 이미지 향상 스튜디오"))
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(if (lightMode) Color.rgb(230,226,255) else Color.rgb(40,32,75))
        }
        hero.addView(label("AI  ·  IMAGE & VIDEO", 11, true).apply { setTextColor(accent) })
        hero.addView(label(tr("细节更清晰，创作更自由","Sharper details. More creative freedom.","더 선명한 디테일, 더 자유로운 창작."), 22, true).apply { setPadding(0, dp(12), 0, dp(18)) })
        hero.addView(label(tr("从图片到视频，在一个简洁空间完成处理。","Enhance photos and videos in one focused workspace.","사진과 동영상을 하나의 작업 공간에서 향상하세요."), 13).apply { setTextColor(muted) })
        parent.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })
        card(parent, tr("图片增强","Photo Studio","사진 스튜디오"),
            tr("选择图片，开始优化流程","Select an image and start your workflow","사진을 선택하고 향상 작업을 시작하세요"),
            tr("打开图片工作台","Open Photo Studio","사진 스튜디오 열기")) { page = "photo"; render() }
        card(parent, tr("视频增强","Video Studio","동영상 스튜디오"),
            tr("本地视频转码与导出","Local video transcoding and export","로컬 동영상 변환 및 내보내기"),
            tr("打开视频工作台","Open Video Studio","동영상 스튜디오 열기")) { page = "video"; render() }
    }

    private fun photoPage(parent: LinearLayout) {
        heading(parent, tr("图片工作台","Photo Studio","사진 스튜디오"),
            tr("导入图片，准备开始处理","Import an image to get started","사진을 가져와 작업을 시작하세요"))
        card(parent, tr("选择图片","Choose Photo","사진 선택"),
            tr("从设备相册导入图片","Import an image from your device","기기 갤러리에서 사진 가져오기"),
            tr("选择文件","Choose file","파일 선택")) { photoPicker.launch("image/*") }
        parent.addView(label(tr("增强工具","Enhancement tools","향상 도구"), 17, true).apply { setPadding(0, dp(12), 0, dp(8)) })
        parent.addView(label(tr("AI 超分辨率、降噪、锐化与人脸修复接口可在后续接入模型后启用。当前版本提供界面框架。",
            "AI upscaling, denoising, sharpening and face recovery require an integrated model. This build provides the UI foundation.",
            "AI 업스케일링, 노이즈 제거, 선명화 및 얼굴 복원은 모델 통합 후 사용할 수 있습니다. 현재 버전은 UI 기반을 제공합니다."), 13).apply { setTextColor(muted) })
    }

    private fun videoPage(parent: LinearLayout) {
        heading(parent, tr("视频工作台","Video Studio","동영상 스튜디오"),
            tr("选择视频并导出本地转码版本","Choose a video and export a local transcode","동영상을 선택해 로컬 변환본을 내보내세요"))
        card(parent, tr("选择视频","Choose Video","동영상 선택"),
            tr("从设备中选择本地视频","Select a local video from your device","기기에서 로컬 동영상 선택"),
            tr("浏览视频","Browse videos","동영상 찾아보기")) { videoPicker.launch("video/*") }
        val export = TextView(this).apply {
            text = tr("开始导出","Export video","동영상 내보내기")
            gravity = Gravity.CENTER; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(0, dp(15), 0, dp(15)); setBackgroundColor(accent)
            setOnClickListener { exportVideo() }
        }
        parent.addView(export, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(16) })
        statusView = label("", 13).apply { setTextColor(muted); setPadding(0, dp(14), 0, dp(8)) }
        parent.addView(statusView)
        parent.addView(label(tr("说明：当前视频导出为本地尺寸转换，不等同于 AI 超分、降噪或细节重建。输出保存在应用专属 Movies 文件夹。",
            "Note: this performs local resizing, not neural AI upscaling, denoising or detail reconstruction. Output is saved in the app's Movies folder.",
            "안내: 현재 기능은 로컬 크기 변환이며 AI 업스케일링, 노이즈 제거 또는 디테일 복원이 아닙니다. 결과는 앱 전용 Movies 폴더에 저장됩니다."), 12).apply { setTextColor(muted); setPadding(0, dp(18), 0, 0) })
    }

    private fun exportVideo() {
        val input = selectedVideo
        if (input == null) {
            Toast.makeText(this, tr("请先选择视频","Choose a video first","먼저 동영상을 선택하세요"), Toast.LENGTH_SHORT).show()
            return
        }
        val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: filesDir
        val output = File(dir, "TopazAI_${System.currentTimeMillis()}.mp4")
        statusView?.text = tr("正在导出，请稍候…","Exporting, please wait…","내보내는 중입니다. 잠시만 기다려 주세요…")
        val transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    runOnUiThread { statusView?.text = tr("导出完成：${output.name}", "Export complete: ${output.name}", "내보내기 완료: ${output.name}") }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    runOnUiThread { statusView?.text = tr("导出失败：${exportException.message}", "Export failed: ${exportException.message}", "내보내기 실패: ${exportException.message}") }
                }
            }).build()
        try {
            transformer.start(MediaItem.fromUri(input), output.absolutePath)
        } catch (e: Exception) {
            statusView?.text = tr("无法开始导出：${e.message}", "Could not start export: ${e.message}", "내보내기를 시작할 수 없습니다: ${e.message}")
        }
    }

    private fun libraryPage(parent: LinearLayout) {
        heading(parent, tr("作品库","Library","라이브러리"),
            tr("查看本机导出内容","Your local exports","기기에 저장된 내보내기"))
        parent.addView(label(tr("导出的视频保存在应用专属 Movies 文件夹中。","Exported videos are stored in the app-specific Movies folder.","내보낸 동영상은 앱 전용 Movies 폴더에 저장됩니다."), 13).apply { setTextColor(muted) })
    }
}
