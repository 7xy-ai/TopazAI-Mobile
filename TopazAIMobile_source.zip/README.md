# Topaz AI Mobile (prototype)

Hybrid Android photo/video enhancer prototype.

## Features in this prototype
- Android 10+
- Dark UI, photo/video picker
- 2x / 4x bitmap resizing and lightweight sharpening
- Original/enhanced preview toggle
- Save enhanced JPEG to Pictures/TopazAIMobile
- Video picker and cloud-processing placeholder

## Not implemented yet
Neural AI super-resolution, face restoration, real cloud API, and video enhancement/export require model/service integration.

## Automatic APK build with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (including `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab. The workflow runs after pushing to `main`/`master`, or start it manually via **Build Android APK → Run workflow**.
4. When the run succeeds, open the run page, scroll to **Artifacts**, and download `TopazAIMobile-debug-apk`. Unzip it to get `app-debug.apk`.
5. On your Android phone, open the APK and allow installation from that source if Android prompts.

This is a debug APK for testing, not a Play Store release. The current app is a functional prototype and does not claim Topaz-level AI quality.
