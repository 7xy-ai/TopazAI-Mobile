package com.example.topazmobile

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import android.view.View
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var preview: ImageView
    private var original: Bitmap? = null
    private var enhanced: Bitmap? = null
    private var selectedImageUri: Uri? = null
    private var selectedVideoUri: Uri? = null
    private var scaleFactor = 2

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            selectedImageUri = it
            contentResolver.openInputStream(it)?.use { stream ->
                original = BitmapFactory.decodeStream(stream)
                enhanced = null
                preview.setImageBitmap(original)
                status("图片已导入 · 本地增强可直接使用")
            }
        }
    }
    private val videoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedVideoUri = uri
        uri?.let { status("视频已选择：${it.lastPathSegment ?: "文件"}\n云端增强接口待配置") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(Color.rgb(13, 15, 20))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        text("TOPAZ AI MOBILE", 22f, Color.WHITE, true)
        text("AI 图片 · 视频增强", 15f, Color.rgb(170, 178, 192), false)
        spacer(18)
        val tabs = row()
        button(tabs, "图片增强") { imagePicker.launch("image/*") }
        button(tabs, "选择视频") { videoPicker.launch("video/*") }
        spacer(14)

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(Color.rgb(28, 31, 39), 18)
            adjustViewBounds = true
            minimumHeight = dp(230)
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(260)))
        spacer(12)

        text("放大倍率", 14f, Color.WHITE, true)
        val scaleRow = row()
        listOf(2, 4).forEach { factor ->
            button(scaleRow, "${factor}×") { scaleFactor = factor; status("已选择 ${factor}× 放大") }
        }
        spacer(10)
        button(root, "✨ 本地增强图片") { runLocalEnhance() }
        button(root, "☁ 云端 AI 增强（接口预留）") {
            status("云端模型接口尚未配置。可接入自建超分服务或兼容 REST API。")
        }
        button(root, "原图 / 增强图对比") {
            val shown = if (preview.tag == "enhanced") original else enhanced
            if (shown != null) {
                preview.setImageBitmap(shown)
                preview.tag = if (shown == enhanced) "enhanced" else "original"
                status(if (preview.tag == "enhanced") "正在显示增强图" else "正在显示原图")
            } else status("请先导入图片并完成增强")
        }
        button(root, "保存增强图片") { saveEnhanced() }
        spacer(16)
        text("视频增强", 18f, Color.WHITE, true)
        text("选择视频后可预留云端处理：降噪、超分、锐化、帧率提升。当前原型未集成视频 AI 模型。", 13f, Color.rgb(170,178,192), false)
        button(root, "选择视频文件") { videoPicker.launch("video/*") }
        button(root, "开始视频增强") {
            if (selectedVideoUri == null) status("请先选择视频")
            else status("视频已就绪。接入云端视频增强服务后即可提交处理。")
        }
        spacer(16)
        text("当前原型：本地基础放大 + 轻度锐化。AI 人脸修复、真实模型超分及云端处理需后续接入模型。", 12f, Color.rgb(130,140,155), false)
    }

    private fun runLocalEnhance() {
        val bmp = original ?: run { status("请先导入一张图片"); return }
        try {
            val w = (bmp.width * scaleFactor).coerceAtMost(4096)
            val h = (bmp.height * scaleFactor).coerceAtMost(4096)
            val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
            enhanced = sharpen(scaled)
            preview.setImageBitmap(enhanced)
            preview.tag = "enhanced"
            status("完成：${w} × ${h} · 本地基础放大与锐化")
        } catch (e: Exception) { status("处理失败：${e.message ?: "未知错误"}") }
    }

    // Basic unsharp-mask style operation on a small preview-safe bitmap. This is not an AI model.
    private fun sharpen(src: Bitmap): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = src.width; val h = src.height
        if (w < 3 || h < 3) return out
        val pixels = IntArray(w*h); src.getPixels(pixels,0,w,0,0,w,h)
        val result = pixels.copyOf()
        for (y in 1 until h-1) for (x in 1 until w-1) {
            val i=y*w+x
            val c=pixels[i]
            fun channel(color:Int, shift:Int)= (color shr shift) and 255
            for (shift in intArrayOf(16,8,0)) {
                val center=channel(c,shift)
                val neighbors=(channel(pixels[i-1],shift)+channel(pixels[i+1],shift)+channel(pixels[i-w],shift)+channel(pixels[i+w],shift))/4
                val value=(center + (center-neighbors)*0.28f).toInt().coerceIn(0,255)
                val mask=255 shl shift
                result[i]=(result[i] and mask.inv()) or (value shl shift)
            }
        }
        out.setPixels(result,0,w,0,0,w,h)
        return out
    }

    private fun saveEnhanced() {
        val bmp = enhanced ?: run { status("请先增强图片"); return }
        try {
            val values = android.content.ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "TopazEnhanced_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TopazAIMobile")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            uri?.let { contentResolver.openOutputStream(it)?.use { stream -> bmp.compress(Bitmap.CompressFormat.JPEG, 95, stream) } }
            status("已保存到 Pictures/TopazAIMobile")
        } catch (e: Exception) { status("保存失败：${e.message}") }
    }

    private fun status(msg:String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
    private fun text(s:String, size:Float, color:Int, bold:Boolean) {
        root.addView(TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0,dp(4),0,dp(4)) })
    }
    private fun spacer(n:Int) { root.addView(View(this), LinearLayout.LayoutParams(1,dp(n))) }
    private fun row(): LinearLayout {
        val r=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        root.addView(r, LinearLayout.LayoutParams(-1, -2))
        return r
    }
    private fun button(parent:LinearLayout, label:String, action:()->Unit) {
        val b=Button(this).apply { text=label; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(44,51,66)); setOnClickListener { action() } }
        val lp=LinearLayout.LayoutParams(-1, dp(52)); lp.setMargins(0,dp(5),0,dp(5))
        parent.addView(b,lp)
    }
    private fun rounded(color:Int, radius:Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
